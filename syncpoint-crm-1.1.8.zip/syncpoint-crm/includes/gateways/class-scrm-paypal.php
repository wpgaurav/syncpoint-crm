<?php
/**
 * PayPal Payment Gateway
 *
 * @package SyncPointCRM
 * @since 1.0.0
 */

namespace SCRM\Gateways;

defined( 'ABSPATH' ) || exit;

class PayPal extends Gateway {

	public $id = 'paypal';
	public $title = 'PayPal';
	public $description = 'Sync transactions from PayPal and accept payments.';

	public function get_settings_fields() {
		return array(
			'enabled'       => array(
				'type'    => 'checkbox',
				'label'   => __( 'Enable PayPal', 'syncpoint-crm' ),
				'default' => false,
			),
			'mode'          => array(
				'type'    => 'select',
				'label'   => __( 'Mode', 'syncpoint-crm' ),
				'options' => array(
					'sandbox' => __( 'Sandbox', 'syncpoint-crm' ),
					'live'    => __( 'Live', 'syncpoint-crm' ),
				),
				'default' => 'sandbox',
			),
			'client_id'     => array(
				'type'  => 'text',
				'label' => __( 'Client ID', 'syncpoint-crm' ),
			),
			'client_secret' => array(
				'type'  => 'password',
				'label' => __( 'Client Secret', 'syncpoint-crm' ),
			),
		);
	}

	public function is_available() {
		$credentials = $this->get_credentials();
		return ! empty( $credentials['enabled'] )
			&& ! empty( $credentials['client_id'] )
			&& ! empty( $credentials['client_secret'] );
	}

	public function sync_transactions( $args = array() ) {
		return array(
			'synced'         => 0,
			'skipped'        => 0,
			'contacts_added' => 0,
			'total'          => 0,
		);
	}

	public function sync_transactions_nvp( $args = array() ) {
		return new \WP_Error( 'paypal_nvp_unavailable', __( 'PayPal NVP sync is not configured.', 'syncpoint-crm' ) );
	}

	public function create_payment_link( $invoice ) {
		return new \WP_Error( 'paypal_payment_link_unavailable', __( 'PayPal payment links are not configured.', 'syncpoint-crm' ) );
	}

	public function process_webhook( $payload ) {
		return true;
	}
}
